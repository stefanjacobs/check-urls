URL Check Übersicht Widget
==========================

A simple widget to use with Übersicht to show if a url returns a 200 on a curl request. Basically it wraps curl and makes a colored oudput using a given list of urls.

Get more widgets at [Übersicht](http://tracesof.net/uebersicht-widgets/)!

Example
-------

![Example!](screenshot.png)

To enable, place the `check-urls.widget` folder in your `Übersicht/widgets` directory.

Usage
-----

Just edit the file `test.list` and put in the urls you want to monitor.